from resources.lib.modules._service import Startup

if __name__ == '__main__':
    s = Startup()
    s.run_startup()